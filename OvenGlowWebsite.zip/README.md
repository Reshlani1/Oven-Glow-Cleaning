# OvenGlow Service Website

This is a simple professional service website for oven repair and maintenance.

## Files
- `index.html`: Main webpage
- `style.css`: Styling
- `/assets/logo.png`: Placeholder logo (replace with your real logo)

## How to Run
1. Extract the ZIP.
2. Open `index.html` in a browser.
3. For GitHub Pages:
   - Push to a repo.
   - Go to Settings > Pages.
   - Set source to `main` branch and `/root`.
   - Done!
